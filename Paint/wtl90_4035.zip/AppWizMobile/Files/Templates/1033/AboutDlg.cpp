// AboutDlg.cpp : implementation of the CAboutDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//?ppc
#include "resourceppc.h"
//?sp
#include "resourcesp.h"
//?end
#include "aboutdlg.h"

