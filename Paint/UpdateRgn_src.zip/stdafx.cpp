// stdafx.cpp : source file that includes just the standard includes
//	UpdateRgn.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#include <atlimpl.cpp>

bool g_isNT = false;
