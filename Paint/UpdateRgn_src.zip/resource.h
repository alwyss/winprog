//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UpdateRgn.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define ID_VIEW_NOLOG                   32772
#define ID_VIEW_NONCLIENT               32773
#define ID_VIEW_DISPLAY_1               32774
#define ID_VIEW_DISPLAY_2               32775
#define ID_VIEW_CSHREDRAW               32776
#define ID_VIEW_CSVREDRAW               32777
#define ID_VIEW_WMERASEBKGND            32778
#define ID_VIEW_SHOWWINDOWCONTENTSWHILEDRAGGING 32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
